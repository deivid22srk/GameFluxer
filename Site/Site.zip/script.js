const API_URL = 'api.php';
const RAWG_API_KEY = 'YOUR_RAWG_API_KEY_HERE';

let config = {
    platforms: []
};

let gamesData = {};
let editingPlatformIndex = -1;
let editingGameId = null;
let currentPlatform = null;
let searchTimeout = null;

function init() {
    loadDataFromServer();
}

async function loadDataFromServer() {
    try {
        showLoading();
        
        const configResponse = await fetch(`${API_URL}?request=config`);
        config = await configResponse.json();
        
        gamesData = {};
        for (const platform of config.platforms) {
            const gamesResponse = await fetch(`${API_URL}?request=games&platform=${encodeURIComponent(platform.name)}`);
            gamesData[platform.name] = await gamesResponse.json();
        }
        
        renderPlatforms();
        updatePlatformSelect();
        hideLoading();
    } catch (error) {
        console.error('Erro ao carregar dados:', error);
        hideLoading();
        alert('Erro ao carregar dados do servidor');
    }
}

function showLoading() {
    const loader = document.createElement('div');
    loader.id = 'loading-overlay';
    loader.innerHTML = `
        <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; 
                    background: rgba(0,0,0,0.8); display: flex; align-items: center; 
                    justify-content: center; z-index: 9999;">
            <div style="text-align: center; color: white;">
                <div style="width: 50px; height: 50px; border: 5px solid #6366f1; 
                           border-top-color: transparent; border-radius: 50%; 
                           animation: spin 1s linear infinite;"></div>
                <p style="margin-top: 20px; font-size: 1.2rem;">Carregando...</p>
            </div>
        </div>
    `;
    document.body.appendChild(loader);
}

function hideLoading() {
    const loader = document.getElementById('loading-overlay');
    if (loader) loader.remove();
}

function switchTab(tabName) {
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    event.target.classList.add('active');
    document.getElementById(`${tabName}-tab`).classList.add('active');
    
    if (tabName === 'platforms') {
        renderPlatforms();
    } else if (tabName === 'games') {
        updatePlatformSelect();
        if (currentPlatform) {
            loadGames();
        }
    }
}

function renderPlatforms() {
    const container = document.getElementById('platforms-list');
    
    if (config.platforms.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1/-1">
                <div class="empty-state-icon">🖥️</div>
                <h3>Nenhuma plataforma cadastrada</h3>
                <p>Adicione sua primeira plataforma para começar</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = config.platforms.map((platform, index) => {
        const gamesCount = gamesData[platform.name] ? gamesData[platform.name].length : 0;
        return `
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">${platform.name}</h3>
                    <div class="card-actions">
                        <button class="icon-btn" onclick="editPlatform(${index})" title="Editar">
                            ✏️
                        </button>
                        <button class="icon-btn danger" onclick="deletePlatform(${index})" title="Excluir">
                            🗑️
                        </button>
                    </div>
                </div>
                <div class="card-info">
                    <div class="card-info-item">
                        <span>📁</span>
                        <span>${platform.databasePath}</span>
                    </div>
                    <div class="card-info-item">
                        <span>🎮</span>
                        <span>${gamesCount} jogos cadastrados</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

function updatePlatformSelect() {
    const select = document.getElementById('platform-select');
    const currentValue = select.value;
    
    select.innerHTML = '<option value="">Selecione uma plataforma</option>' +
        config.platforms.map(platform => 
            `<option value="${platform.name}">${platform.name}</option>`
        ).join('');
    
    if (currentValue && config.platforms.find(p => p.name === currentValue)) {
        select.value = currentValue;
    }
}

function loadGames() {
    const select = document.getElementById('platform-select');
    const selectedPlatform = select.value;
    const container = document.getElementById('games-list');
    const addBtn = document.getElementById('add-game-btn');
    
    if (!selectedPlatform) {
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1/-1">
                <div class="empty-state-icon">🎮</div>
                <h3>Selecione uma plataforma</h3>
                <p>Escolha uma plataforma para ver seus jogos</p>
            </div>
        `;
        addBtn.disabled = true;
        return;
    }
    
    addBtn.disabled = false;
    currentPlatform = selectedPlatform;
    
    const games = gamesData[selectedPlatform] || [];
    
    if (games.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1/-1">
                <div class="empty-state-icon">🎮</div>
                <h3>Nenhum jogo cadastrado</h3>
                <p>Adicione jogos para a plataforma ${selectedPlatform}</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = games.map(game => `
        <div class="card game-card">
            <img src="${game.bannerUrl}" alt="${game.name}" class="game-banner" 
                 onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22200%22%3E%3Crect fill=%22%23334155%22 width=%22400%22 height=%22200%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 fill=%22%2394a3b8%22 font-family=%22Arial%22 font-size=%2220%22 text-anchor=%22middle%22 dy=%22.3em%22%3ESem imagem%3C/text%3E%3C/svg%3E'">
            <div class="card-header">
                <div>
                    <h3 class="card-title">${game.name}</h3>
                    <span class="game-rating">⭐ ${game.rating}</span>
                </div>
                <div class="card-actions">
                    <button class="icon-btn" onclick="editGame('${game.id}')" title="Editar">
                        ✏️
                    </button>
                    <button class="icon-btn danger" onclick="deleteGame('${game.id}')" title="Excluir">
                        🗑️
                    </button>
                </div>
            </div>
            <div class="card-info">
                <div class="card-info-item">
                    <span>📦</span>
                    <span>${game.size}</span>
                </div>
                <div class="card-info-item">
                    <span>🏷️</span>
                    <span>${game.category}</span>
                </div>
                <div class="card-info-item">
                    <span>👨‍💻</span>
                    <span>${game.developer}</span>
                </div>
                <div class="card-info-item">
                    <span>📅</span>
                    <span>${game.releaseDate}</span>
                </div>
            </div>
        </div>
    `).join('');
}

function openPlatformModal(index = -1) {
    editingPlatformIndex = index;
    const modal = document.getElementById('platform-modal');
    const title = document.getElementById('platform-modal-title');
    const form = document.getElementById('platform-form');
    
    form.reset();
    
    if (index >= 0) {
        title.textContent = 'Editar Plataforma';
        const platform = config.platforms[index];
        document.getElementById('platform-name').value = platform.name;
    } else {
        title.textContent = 'Nova Plataforma';
    }
    
    modal.classList.add('active');
}

function closePlatformModal() {
    document.getElementById('platform-modal').classList.remove('active');
    editingPlatformIndex = -1;
}

async function savePlatform(event) {
    event.preventDefault();
    
    const name = document.getElementById('platform-name').value.trim();
    
    try {
        showLoading();
        
        if (editingPlatformIndex >= 0) {
            const oldName = config.platforms[editingPlatformIndex].name;
            const response = await fetch(`${API_URL}?request=platform`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ oldName, name })
            });
            
            const result = await response.json();
            config = result.config;
        } else {
            const response = await fetch(`${API_URL}?request=platform`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name })
            });
            
            const result = await response.json();
            config = result.config;
        }
        
        await loadDataFromServer();
        closePlatformModal();
        hideLoading();
    } catch (error) {
        console.error('Erro ao salvar plataforma:', error);
        hideLoading();
        alert('Erro ao salvar plataforma');
    }
}

function editPlatform(index) {
    openPlatformModal(index);
}

async function deletePlatform(index) {
    const platform = config.platforms[index];
    const gamesCount = gamesData[platform.name] ? gamesData[platform.name].length : 0;
    
    let confirmMsg = `Deseja excluir a plataforma "${platform.name}"?`;
    if (gamesCount > 0) {
        confirmMsg = `A plataforma "${platform.name}" possui ${gamesCount} jogos. Deseja realmente excluir?`;
    }
    
    if (!confirm(confirmMsg)) return;
    
    try {
        showLoading();
        
        await fetch(`${API_URL}?request=platform`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: platform.name })
        });
        
        await loadDataFromServer();
        hideLoading();
    } catch (error) {
        console.error('Erro ao excluir plataforma:', error);
        hideLoading();
        alert('Erro ao excluir plataforma');
    }
}

function openGameModal(gameId = null) {
    if (!currentPlatform) {
        alert('Selecione uma plataforma primeiro');
        return;
    }
    
    editingGameId = gameId;
    const modal = document.getElementById('game-modal');
    const title = document.getElementById('game-modal-title');
    const form = document.getElementById('game-form');
    const searchContainer = document.getElementById('game-search-container');
    
    form.reset();
    searchContainer.style.display = gameId ? 'none' : 'block';
    
    if (gameId) {
        title.textContent = 'Editar Jogo';
        const games = gamesData[currentPlatform] || [];
        const game = games.find(g => g.id === gameId);
        
        if (game) {
            fillGameForm(game);
        }
    } else {
        title.textContent = 'Novo Jogo';
    }
    
    modal.classList.add('active');
}

function closeGameModal() {
    document.getElementById('game-modal').classList.remove('active');
    document.getElementById('game-search-results').innerHTML = '';
    editingGameId = null;
}

async function searchGames(query) {
    if (!query || query.length < 3) {
        document.getElementById('game-search-results').innerHTML = '';
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}?request=search_game&query=${encodeURIComponent(query)}`);
        const data = await response.json();
        
        const resultsContainer = document.getElementById('game-search-results');
        
        if (data.results && data.results.length > 0) {
            resultsContainer.innerHTML = data.results.map(game => `
                <div class="search-result-item" onclick="selectGameFromAPI(${game.id})">
                    <img src="${game.background_image || ''}" alt="${game.name}" 
                         onerror="this.style.display='none'">
                    <div>
                        <strong>${game.name}</strong>
                        <p>${game.released || 'Data desconhecida'}</p>
                    </div>
                </div>
            `).join('');
        } else {
            resultsContainer.innerHTML = '<p style="padding: 10px; text-align: center;">Nenhum jogo encontrado</p>';
        }
    } catch (error) {
        console.error('Erro ao buscar jogos:', error);
    }
}

async function selectGameFromAPI(gameId) {
    try {
        showLoading();
        
        const response = await fetch(`${API_URL}?request=game_details&id=${gameId}`);
        const game = await response.json();
        
        const formattedGame = {
            name: game.name,
            description: game.description_raw || game.description || '',
            version: '1.0',
            size: 'A definir',
            rating: game.rating || 0,
            developer: game.developers && game.developers[0] ? game.developers[0].name : 'Desconhecido',
            category: game.genres && game.genres[0] ? game.genres[0].name : 'Geral',
            iconUrl: game.background_image || '',
            bannerUrl: game.background_image || '',
            screenshots: game.short_screenshots ? game.short_screenshots.slice(0, 3).map(s => s.image).join(', ') : '',
            downloadUrl: '',
            releaseDate: game.released || new Date().toISOString().split('T')[0]
        };
        
        fillGameForm(formattedGame);
        document.getElementById('game-search-container').style.display = 'none';
        document.getElementById('game-search-results').innerHTML = '';
        hideLoading();
    } catch (error) {
        console.error('Erro ao buscar detalhes do jogo:', error);
        hideLoading();
        alert('Erro ao buscar informações do jogo');
    }
}

function fillGameForm(game) {
    document.getElementById('game-name').value = game.name || '';
    document.getElementById('game-description').value = game.description || '';
    document.getElementById('game-version').value = game.version || '1.0';
    document.getElementById('game-size').value = game.size || '';
    document.getElementById('game-rating').value = game.rating || 0;
    document.getElementById('game-developer').value = game.developer || '';
    document.getElementById('game-category').value = game.category || '';
    document.getElementById('game-icon-url').value = game.iconUrl || '';
    document.getElementById('game-banner-url').value = game.bannerUrl || '';
    document.getElementById('game-screenshots').value = game.screenshots || '';
    document.getElementById('game-download-url').value = game.downloadUrl || '';
    document.getElementById('game-release-date').value = game.releaseDate || '';
}

async function saveGame(event) {
    event.preventDefault();
    
    if (!currentPlatform) {
        alert('Selecione uma plataforma primeiro');
        return;
    }
    
    const game = {
        id: editingGameId || Date.now().toString(),
        name: document.getElementById('game-name').value.trim(),
        description: document.getElementById('game-description').value.trim(),
        version: document.getElementById('game-version').value.trim(),
        size: document.getElementById('game-size').value.trim(),
        rating: parseFloat(document.getElementById('game-rating').value),
        developer: document.getElementById('game-developer').value.trim(),
        category: document.getElementById('game-category').value.trim(),
        platform: currentPlatform,
        iconUrl: document.getElementById('game-icon-url').value.trim(),
        bannerUrl: document.getElementById('game-banner-url').value.trim(),
        screenshots: document.getElementById('game-screenshots').value.trim(),
        downloadUrl: document.getElementById('game-download-url').value.trim(),
        releaseDate: document.getElementById('game-release-date').value
    };
    
    try {
        showLoading();
        
        if (editingGameId) {
            await fetch(`${API_URL}?request=game`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ platform: currentPlatform, game })
            });
        } else {
            await fetch(`${API_URL}?request=game`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ platform: currentPlatform, game })
            });
        }
        
        await loadDataFromServer();
        loadGames();
        closeGameModal();
        hideLoading();
    } catch (error) {
        console.error('Erro ao salvar jogo:', error);
        hideLoading();
        alert('Erro ao salvar jogo');
    }
}

function editGame(gameId) {
    openGameModal(gameId);
}

async function deleteGame(gameId) {
    if (!confirm('Deseja excluir este jogo?')) return;
    
    try {
        showLoading();
        
        await fetch(`${API_URL}?request=game`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ platform: currentPlatform, gameId })
        });
        
        await loadDataFromServer();
        loadGames();
        hideLoading();
    } catch (error) {
        console.error('Erro ao excluir jogo:', error);
        hideLoading();
        alert('Erro ao excluir jogo');
    }
}

async function downloadZip() {
    if (config.platforms.length === 0) {
        alert('Adicione pelo menos uma plataforma antes de baixar o ZIP');
        return;
    }
    
    try {
        showLoading();
        window.location.href = `${API_URL}?request=download`;
        setTimeout(hideLoading, 2000);
    } catch (error) {
        console.error('Erro ao baixar ZIP:', error);
        hideLoading();
        alert('Erro ao baixar o arquivo ZIP');
    }
}

function importZip() {
    alert('Função de importação não disponível na versão com backend. Use a interface para adicionar dados.');
}

document.getElementById('game-search').addEventListener('input', function(e) {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        searchGames(e.target.value);
    }, 500);
});

window.onclick = function(event) {
    const platformModal = document.getElementById('platform-modal');
    const gameModal = document.getElementById('game-modal');
    
    if (event.target === platformModal) {
        closePlatformModal();
    }
    if (event.target === gameModal) {
        closeGameModal();
    }
}

init();
