<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

$dataDir = __DIR__ . '/data';
$configFile = $dataDir . '/config.json';
$gamesDir = $dataDir . '/databases';

if (!file_exists($dataDir)) {
    mkdir($dataDir, 0777, true);
}

if (!file_exists($gamesDir)) {
    mkdir($gamesDir, 0777, true);
}

if (!file_exists($configFile)) {
    file_put_contents($configFile, json_encode(['platforms' => []], JSON_PRETTY_PRINT));
}

function loadConfig() {
    global $configFile;
    return json_decode(file_get_contents($configFile), true);
}

function saveConfig($config) {
    global $configFile;
    file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function loadGames($platform) {
    global $gamesDir;
    $fileName = strtolower(str_replace(' ', '_', $platform)) . '_games.json';
    $filePath = $gamesDir . '/' . $fileName;
    
    if (!file_exists($filePath)) {
        file_put_contents($filePath, json_encode([], JSON_PRETTY_PRINT));
        return [];
    }
    
    return json_decode(file_get_contents($filePath), true);
}

function saveGames($platform, $games) {
    global $gamesDir;
    $fileName = strtolower(str_replace(' ', '_', $platform)) . '_games.json';
    $filePath = $gamesDir . '/' . $fileName;
    file_put_contents($filePath, json_encode($games, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

$method = $_SERVER['REQUEST_METHOD'];
$request = isset($_GET['request']) ? $_GET['request'] : '';

if ($method === 'GET') {
    if ($request === 'config') {
        echo json_encode(loadConfig());
        
    } elseif ($request === 'games') {
        $platform = isset($_GET['platform']) ? $_GET['platform'] : '';
        if ($platform) {
            echo json_encode(loadGames($platform));
        } else {
            echo json_encode(['error' => 'Platform required']);
        }
        
    } elseif ($request === 'download') {
        $config = loadConfig();
        
        $zip = new ZipArchive();
        $zipName = 'gamefluxer_database_' . date('Y-m-d_H-i-s') . '.zip';
        $zipPath = sys_get_temp_dir() . '/' . $zipName;
        
        if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
            $zip->addFromString('config.json', json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            
            foreach ($config['platforms'] as $platform) {
                $games = loadGames($platform['name']);
                $zip->addFromString($platform['databasePath'], json_encode($games, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }
            
            $zip->close();
            
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $zipName . '"');
            header('Content-Length: ' . filesize($zipPath));
            readfile($zipPath);
            unlink($zipPath);
            exit;
        }
        
    } elseif ($request === 'search_game') {
        $query = isset($_GET['query']) ? $_GET['query'] : '';
        $apiKey = 'f6f61815152944838d1a1102e562d799';
        
        if (!$query) {
            echo json_encode(['error' => 'Query required']);
            exit;
        }
        
        $url = "https://api.rawg.io/api/games?key={$apiKey}&search=" . urlencode($query) . "&page_size=5";
        $response = file_get_contents($url);
        echo $response;
        
    } elseif ($request === 'game_details') {
        $gameId = isset($_GET['id']) ? $_GET['id'] : '';
        $apiKey = 'f6f61815152944838d1a1102e562d799';
        
        if (!$gameId) {
            echo json_encode(['error' => 'Game ID required']);
            exit;
        }
        
        $url = "https://api.rawg.io/api/games/{$gameId}?key={$apiKey}";
        $response = file_get_contents($url);
        echo $response;
        
    } else {
        echo json_encode(['error' => 'Invalid request']);
    }
    
} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if ($request === 'platform') {
        $config = loadConfig();
        $platformName = $data['name'];
        $sanitizedName = strtolower(str_replace(' ', '_', $platformName));
        $databasePath = "databases/{$sanitizedName}_games.json";
        
        $config['platforms'][] = [
            'name' => $platformName,
            'databasePath' => $databasePath
        ];
        
        saveConfig($config);
        echo json_encode(['success' => true, 'config' => $config]);
        
    } elseif ($request === 'game') {
        $platform = $data['platform'];
        $game = $data['game'];
        
        $games = loadGames($platform);
        $game['id'] = isset($game['id']) ? $game['id'] : uniqid();
        $games[] = $game;
        
        saveGames($platform, $games);
        echo json_encode(['success' => true, 'game' => $game]);
        
    } else {
        echo json_encode(['error' => 'Invalid request']);
    }
    
} elseif ($method === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if ($request === 'platform') {
        $config = loadConfig();
        $oldName = $data['oldName'];
        $newName = $data['name'];
        
        foreach ($config['platforms'] as &$platform) {
            if ($platform['name'] === $oldName) {
                $platform['name'] = $newName;
                $sanitizedName = strtolower(str_replace(' ', '_', $newName));
                $platform['databasePath'] = "databases/{$sanitizedName}_games.json";
                
                $oldGames = loadGames($oldName);
                saveGames($newName, $oldGames);
                
                $oldFileName = strtolower(str_replace(' ', '_', $oldName)) . '_games.json';
                $oldFilePath = $gamesDir . '/' . $oldFileName;
                if (file_exists($oldFilePath)) {
                    unlink($oldFilePath);
                }
                
                break;
            }
        }
        
        saveConfig($config);
        echo json_encode(['success' => true, 'config' => $config]);
        
    } elseif ($request === 'game') {
        $platform = $data['platform'];
        $game = $data['game'];
        
        $games = loadGames($platform);
        foreach ($games as &$g) {
            if ($g['id'] === $game['id']) {
                $g = $game;
                break;
            }
        }
        
        saveGames($platform, $games);
        echo json_encode(['success' => true, 'game' => $game]);
        
    } else {
        echo json_encode(['error' => 'Invalid request']);
    }
    
} elseif ($method === 'DELETE') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if ($request === 'platform') {
        $config = loadConfig();
        $platformName = $data['name'];
        
        $config['platforms'] = array_filter($config['platforms'], function($p) use ($platformName) {
            return $p['name'] !== $platformName;
        });
        $config['platforms'] = array_values($config['platforms']);
        
        $fileName = strtolower(str_replace(' ', '_', $platformName)) . '_games.json';
        $filePath = $gamesDir . '/' . $fileName;
        if (file_exists($filePath)) {
            unlink($filePath);
        }
        
        saveConfig($config);
        echo json_encode(['success' => true, 'config' => $config]);
        
    } elseif ($request === 'game') {
        $platform = $data['platform'];
        $gameId = $data['gameId'];
        
        $games = loadGames($platform);
        $games = array_filter($games, function($g) use ($gameId) {
            return $g['id'] !== $gameId;
        });
        $games = array_values($games);
        
        saveGames($platform, $games);
        echo json_encode(['success' => true]);
        
    } else {
        echo json_encode(['error' => 'Invalid request']);
    }
    
} else {
    echo json_encode(['error' => 'Method not allowed']);
}
?>
